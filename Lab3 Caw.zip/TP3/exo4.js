const fs = require("fs");

const WriteFi = (st) => {
  const Write = fs.writeFileSync("./exo4.txt", st);
};

WriteFi("Ayoub");
