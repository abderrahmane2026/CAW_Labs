const fs = require("fs");

const ReadFL = (a) => {
  const read = fs.readFileSync(a);
  console.log(read.toString());
};

ReadFL("/Users/bekkouche/Desktop/TP3/test.txt");
